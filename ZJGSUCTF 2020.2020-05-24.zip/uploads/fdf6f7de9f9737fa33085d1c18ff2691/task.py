#!/usr/bin/env python
import hashlib
from secret import flag

if flag.startswith('zjgsuctf{') and flag.endswith('}'):
    pass
else:
    raise ValueError, 'Something went wrong...'

def lfsr(R, mask):
    output = (R << 1) & 0xffffffff
    i = (R & mask) & 0xffffffff
    last_bit = 0
    while i != 0:
        last_bit ^= (i & 1)
        i >>= 1
    output ^= last_bit
    return output, last_bit

R = int(flag[9:-1], 2)
h = hashlib.md5(flag).hexdigest()
mask = ''
for c in h:
    mask += str(int(c, 16) % 2)
mask = int(mask, 2)
with open('mask', 'wb') as f:
    f.write(bin(mask))
with open('log', 'wb') as f:
    for i in range(100):
        c = 0
        for j in range(8):
            R, output = lfsr(R, mask)
            c = (c << 1) ^ output
        f.write(chr(c))

